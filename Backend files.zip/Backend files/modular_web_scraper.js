// =============================================================================
// MODULAR WEB SCRAPER WITH INTELLIGENT FALLBACKS
// Multi-method scraping with GUI interface and quality control
// =============================================================================

export default {
    async fetch(request, env, ctx) {
        return await handleRequest(request, env, ctx);
    }
};

// Scraping Methods - Modular Design
class ScrapingMethods {
    constructor(env) {
        this.env = env;
        this.methods = [
            this.cloudflareWorkerScrape,
            this.puppeteerApiScrape,
            this.simpleHttpScrape,
            this.archiveOrgFallback
        ];
    }

    // Method 1: Direct Cloudflare Worker Scraping
    async cloudflareWorkerScrape(url) {
        try {
            const response = await fetch(url, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const html = await response.text();
            return {
                success: true,
                method: 'cloudflare_worker',
                html: html,
                size: html.length,
                contentType: response.headers.get('content-type') || 'text/html'
            };
        } catch (error) {
            return {
                success: false,
                method: 'cloudflare_worker',
                error: error.message
            };
        }
    }

    // Method 2: External API Scraping (for JS-heavy sites)
    async puppeteerApiScrape(url) {
        try {
            // Example with ScrapingBee, ScraperAPI, or similar
            const apiUrl = 'https://app.scrapingbee.com/api/v1/';
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    api_key: this.env.SCRAPING_API_KEY, // Store in Cloudflare secrets
                    url: url,
                    render_js: true,
                    premium_proxy: false
                })
            });

            if (!response.ok) {
                throw new Error(`API returned ${response.status}`);
            }

            const html = await response.text();
            return {
                success: true,
                method: 'puppeteer_api',
                html: html,
                size: html.length,
                renderTime: 'dynamic'
            };
        } catch (error) {
            return {
                success: false,
                method: 'puppeteer_api',
                error: error.message
            };
        }
    }

    // Method 3: Simple HTTP with Different Headers/IPs
    async simpleHttpScrape(url) {
        try {
            const userAgents = [
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101',
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
            ];

            const randomUA = userAgents[Math.floor(Math.random() * userAgents.length)];

            const response = await fetch(url, {
                headers: {
                    'User-Agent': randomUA,
                    'Accept': 'text/html,application/xhtml+xml',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const html = await response.text();
            return {
                success: true,
                method: 'simple_http',
                html: html,
                size: html.length,
                userAgent: randomUA
            };
        } catch (error) {
            return {
                success: false,
                method: 'simple_http',
                error: error.message
            };
        }
    }

    // Method 4: Archive.org Fallback
    async archiveOrgFallback(url) {
        try {
            const archiveUrl = `https://web.archive.org/web/20241201000000/${url}`;
            const response = await fetch(archiveUrl);

            if (!response.ok) {
                throw new Error(`Archive returned ${response.status}`);
            }

            const html = await response.text();
            return {
                success: true,
                method: 'archive_org',
                html: html,
                size: html.length,
                note: 'Retrieved from Internet Archive'
            };
        } catch (error) {
            return {
                success: false,
                method: 'archive_org',
                error: error.message
            };
        }
    }

    // Smart Fallback Chain
    async scrapeWithFallbacks(url, options = {}) {
        const results = [];
        
        for (const method of this.methods) {
            try {
                const result = await method.call(this, url);
                results.push(result);
                
                if (result.success) {
                    // Validate content quality
                    const validation = this.validateContent(result.html, options.expectedElements);
                    
                    if (validation.isValid || options.acceptAnyContent) {
                        return {
                            ...result,
                            validation: validation,
                            attemptedMethods: results.length
                        };
                    }
                }
            } catch (error) {
                results.push({
                    success: false,
                    method: method.name,
                    error: error.message
                });
            }

            // Rate limiting between attempts
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        return {
            success: false,
            error: 'All scraping methods failed',
            attempts: results
        };
    }

    // Content Validation
    validateContent(html, expectedElements = []) {
        if (!html || html.length < 100) {
            return { isValid: false, reason: 'Content too short' };
        }

        // Check for common error pages
        const errorIndicators = [
            'access denied',
            'rate limited',
            'captcha',
            'bot detected',
            '403 forbidden',
            '404 not found',
            'cloudflare'
        ];

        const lowerHtml = html.toLowerCase();
        for (const indicator of errorIndicators) {
            if (lowerHtml.includes(indicator)) {
                return { isValid: false, reason: `Contains error indicator: ${indicator}` };
            }
        }

        // Check for expected elements
        if (expectedElements.length > 0) {
            const missingElements = expectedElements.filter(element => !html.includes(element));
            if (missingElements.length > 0) {
                return { 
                    isValid: false, 
                    reason: `Missing expected elements: ${missingElements.join(', ')}` 
                };
            }
        }

        // Basic HTML structure check
        if (!html.includes('<body') && !html.includes('<html')) {
            return { isValid: false, reason: 'Invalid HTML structure' };
        }

        return { 
            isValid: true, 
            hasTable: html.includes('<table'),
            hasForm: html.includes('<form'),
            linkCount: (html.match(/<a\s+href/gi) || []).length,
            size: html.length
        };
    }
}

// URL Management System
class URLManager {
    constructor(env) {
        this.env = env;
    }

    // Process single URL
    async processSingleURL(url, options = {}) {
        const scraper = new ScrapingMethods(this.env);
        const result = await scraper.scrapeWithFallbacks(url, options);
        
        if (result.success) {
            // Store in D1 database
            await this.storeScrapedContent(url, result);
        }
        
        return result;
    }

    // Process URL list
    async processURLList(urls, options = {}) {
        const results = [];
        const batchSize = options.batchSize || 5;
        
        for (let i = 0; i < urls.length; i += batchSize) {
            const batch = urls.slice(i, i + batchSize);
            const batchPromises = batch.map(url => this.processSingleURL(url, options));
            
            const batchResults = await Promise.allSettled(batchPromises);
            results.push(...batchResults);
            
            // Progress callback
            if (options.onProgress) {
                options.onProgress({
                    completed: Math.min(i + batchSize, urls.length),
                    total: urls.length,
                    percentage: Math.round((Math.min(i + batchSize, urls.length) / urls.length) * 100)
                });
            }
            
            // Rate limiting between batches
            if (i + batchSize < urls.length) {
                await new Promise(resolve => setTimeout(resolve, options.batchDelay || 2000));
            }
        }
        
        return results;
    }

    // Detect pagination
    async detectPagination(url) {
        const scraper = new ScrapingMethods(this.env);
        const result = await scraper.scrapeWithFallbacks(url);
        
        if (!result.success) {
            return { hasPagination: false };
        }

        const paginationIndicators = [
            /next\s*page/i,
            /page\s*\d+/i,
            />\s*next\s*</i,
            /pagination/i,
            /page-\d+/i
        ];

        const hasPagination = paginationIndicators.some(regex => regex.test(result.html));
        
        // Extract page numbers if pagination detected
        let maxPage = 1;
        if (hasPagination) {
            const pageMatches = result.html.match(/page[=\-\s](\d+)/gi);
            if (pageMatches) {
                const pageNumbers = pageMatches.map(match => parseInt(match.match(/\d+/)[0]));
                maxPage = Math.max(...pageNumbers);
            }
        }

        return {
            hasPagination,
            estimatedPages: maxPage,
            paginationUrls: this.generatePaginationUrls(url, maxPage)
        };
    }

    generatePaginationUrls(baseUrl, maxPage) {
        const urls = [];
        for (let i = 1; i <= maxPage; i++) {
            // Common pagination patterns
            const patterns = [
                `${baseUrl}?page=${i}`,
                `${baseUrl}/page/${i}`,
                `${baseUrl}&page=${i}`,
                `${baseUrl}?p=${i}`
            ];
            urls.push(...patterns);
        }
        return [...new Set(urls)]; // Remove duplicates
    }

    async storeScrapedContent(url, result) {
        try {
            await this.env.SCRAPER_DB.prepare(`
                INSERT INTO scraped_content 
                (url, html_content, method_used, size, scraped_at, validation_result)
                VALUES (?, ?, ?, ?, ?, ?)
            `).bind(
                url,
                result.html,
                result.method,
                result.size,
                new Date().toISOString(),
                JSON.stringify(result.validation)
            ).run();
        } catch (error) {
            console.error('Failed to store scraped content:', error);
        }
    }
}

// Main Request Handler
async function handleRequest(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (request.method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    try {
        if (path.startsWith('/api/')) {
            return await handleAPIRequest(request, env, corsHeaders);
        }

        return new Response(generateWebScraperGUI(), {
            headers: { 
                'Content-Type': 'text/html',
                ...corsHeaders 
            }
        });

    } catch (error) {
        return new Response(JSON.stringify({ 
            error: 'Internal server error',
            details: error.message 
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                ...corsHeaders 
            }
        });
    }
}

async function handleAPIRequest(request, env, corsHeaders) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    const urlManager = new URLManager(env);

    // Single URL scraping
    if (path === '/api/scrape' && method === 'POST') {
        const data = await request.json();
        const result = await urlManager.processSingleURL(data.url, data.options || {});
        
        return new Response(JSON.stringify(result), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }

    // Batch URL scraping
    if (path === '/api/scrape-batch' && method === 'POST') {
        const data = await request.json();
        const results = await urlManager.processURLList(data.urls, data.options || {});
        
        return new Response(JSON.stringify({
            success: true,
            results: results,
            summary: {
                total: results.length,
                successful: results.filter(r => r.value?.success).length,
                failed: results.filter(r => r.status === 'rejected' || !r.value?.success).length
            }
        }), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }

    // Pagination detection
    if (path === '/api/detect-pagination' && method === 'POST') {
        const data = await request.json();
        const result = await urlManager.detectPagination(data.url);
        
        return new Response(JSON.stringify(result), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }

    // Get scraped content
    if (path === '/api/content' && method === 'GET') {
        const limit = url.searchParams.get('limit') || 50;
        
        const content = await env.SCRAPER_DB.prepare(`
            SELECT url, method_used, size, scraped_at, validation_result
            FROM scraped_content 
            ORDER BY scraped_at DESC 
            LIMIT ?
        `).bind(limit).all();

        return new Response(JSON.stringify({
            success: true,
            content: content.results
        }), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }

    return new Response('Not Found', { 
        status: 404,
        headers: corsHeaders 
    });
}

function generateWebScraperGUI() {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modular Web Scraper</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .tabs { display: flex; background: white; border-radius: 8px; margin-bottom: 20px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .tab { flex: 1; padding: 15px; text-align: center; cursor: pointer; border: none; background: none; font-size: 16px; }
        .tab.active { background: #2563eb; color: white; }
        .tab:hover:not(.active) { background: #f3f4f6; }
        .tab-content { display: none; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .tab-content.active { display: block; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 4px; }
        .btn { padding: 10px 20px; background: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }
        .btn:hover { background: #1d4ed8; }
        .btn-danger { background: #dc2626; }
        .btn-danger:hover { background: #b91c1c; }
        .results { margin-top: 20px; padding: 15px; background: #f9fafb; border-radius: 8px; }
        .success { color: #059669; }
        .error { color: #dc2626; }
        .method-badge { padding: 2px 6px; background: #3b82f6; color: white; border-radius: 3px; font-size: 0.8em; }
        .validation-info { margin-top: 10px; padding: 10px; background: #e0f2fe; border-radius: 4px; }
        .progress-bar { width: 100%; height: 20px; background: #e5e7eb; border-radius: 10px; overflow: hidden; margin: 10px 0; }
        .progress-fill { height: 100%; background: #2563eb; transition: width 0.3s ease; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🕷️ Modular Web Scraper</h1>
            <p>Intelligent multi-method scraping with automatic fallbacks</p>
        </div>

        <div class="tabs">
            <button class="tab active" onclick="switchTab('single')">Single URL</button>
            <button class="tab" onclick="switchTab('batch')">Batch URLs</button>
            <button class="tab" onclick="switchTab('pagination')">Pagination</button>
            <button class="tab" onclick="switchTab('history')">History</button>
        </div>

        <!-- Single URL Tab -->
        <div class="tab-content active" id="single-tab">
            <h3>Single URL Scraping</h3>
            <div class="form-group">
                <label for="singleUrl">URL to Scrape:</label>
                <input type="url" id="singleUrl" placeholder="https://example.com">
            </div>
            <div class="form-group">
                <label for="expectedElements">Expected Elements (optional):</label>
                <input type="text" id="expectedElements" placeholder="table, .price, #content (comma-separated)">
            </div>
            <div class="form-group">
                <label>
                    <input type="checkbox" id="acceptAnyContent"> Accept any content (skip validation)
                </label>
            </div>
            <button class="btn" onclick="scrapeSingle()">Scrape URL</button>
            <div id="singleResults" class="results" style="display: none;"></div>
        </div>

        <!-- Batch URLs Tab -->
        <div class="tab-content" id="batch-tab">
            <h3>Batch URL Scraping</h3>
            <div class="form-group">
                <label for="batchUrls">URLs (one per line):</label>
                <textarea id="batchUrls" rows="8" placeholder="https://example1.com
https://example2.com
https://example3.com"></textarea>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label for="batchSize">Batch Size:</label>
                    <input type="number" id="batchSize" value="3" min="1" max="10">
                </div>
                <div class="form-group">
                    <label for="batchDelay">Delay Between Batches (ms):</label>
                    <input type="number" id="batchDelay" value="2000" min="500">
                </div>
            </div>
            <button class="btn" onclick="scrapeBatch()">Start Batch Scrape</button>
            <div id="batchProgress" style="display: none; margin-top: 15px;">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: 0%;"></div>
                </div>
                <p id="progressText">Processing...</p>
            </div>
            <div id="batchResults" class="results" style="display: none;"></div>
        </div>

        <!-- Pagination Tab -->
        <div class="tab-content" id="pagination-tab">
            <h3>Pagination Detection & Scraping</h3>
            <div class="form-group">
                <label for="paginationUrl">Base URL:</label>
                <input type="url" id="paginationUrl" placeholder="https://example.com/page1">
            </div>
            <button class="btn" onclick="detectPagination()">Detect Pagination</button>
            <button class="btn" onclick="scrapeAllPages()" id="scrapeAllBtn" style="display: none;">Scrape All Pages</button>
            <div id="paginationResults" class="results" style="display: none;"></div>
        </div>

        <!-- History Tab -->
        <div class="tab-content" id="history-tab">
            <h3>Scraping History</h3>
            <button class="btn" onclick="loadHistory()">Refresh History</button>
            <div id="historyResults" class="results">
                <p>Click "Refresh History" to load recent scraping results.</p>
            </div>
        </div>
    </div>

    <script>
        function switchTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });

            // Show selected tab
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');
        }

        async function scrapeSingle() {
            const url = document.getElementById('singleUrl').value.trim();
            const expectedElements = document.getElementById('expectedElements').value.trim();
            const acceptAnyContent = document.getElementById('acceptAnyContent').checked;

            if (!url) {
                alert('Please enter a URL');
                return;
            }

            const resultsDiv = document.getElementById('singleResults');
            resultsDiv.style.display = 'block';
            resultsDiv.innerHTML = '<p>Scraping in progress...</p>';

            try {
                const response = await fetch('/api/scrape', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        url: url,
                        options: {
                            expectedElements: expectedElements ? expectedElements.split(',').map(s => s.trim()) : [],
                            acceptAnyContent: acceptAnyContent
                        }
                    })
                });

                const data = await response.json();
                displaySingleResult(data, resultsDiv);

            } catch (error) {
                resultsDiv.innerHTML = \`<p class="error">Error: \${error.message}</p>\`;
            }
        }

        function displaySingleResult(result, container) {
            if (result.success) {
                container.innerHTML = \`
                    <div class="success">
                        <h4>✅ Successfully Scraped</h4>
                        <p><strong>Method:</strong> <span class="method-badge">\${result.method}</span></p>
                        <p><strong>Size:</strong> \${(result.size / 1024).toFixed(1)} KB</p>
                        <p><strong>Attempts:</strong> \${result.attemptedMethods}</p>
                        \${result.validation ? \`
                            <div class="validation-info">
                                <strong>Validation:</strong>
                                <ul>
                                    <li>Valid: \${result.validation.isValid ? '✅' : '❌'}</li>
                                    <li>Has Tables: \${result.validation.hasTable ? '✅' : '❌'}</li>
                                    <li>Link Count: \${result.validation.linkCount || 0}</li>
                                </ul>
                            </div>
                        \` : ''}
                    </div>
                \`;
            } else {
                container.innerHTML = \`
                    <div class="error">
                        <h4>❌ Scraping Failed</h4>
                        <p><strong>Error:</strong> \${result.error}</p>
                        \${result.attempts ? \`
                            <details>
                                <summary>Attempted Methods:</summary>
                                <ul>
                                    \${result.attempts.map(attempt => 
                                        \`<li>\${attempt.method}: \${attempt.success ? '✅' : '❌ ' + attempt.error}\</li>\`
                                    ).join('')}
                                </ul>
                            </details>
                        \` : ''}
                    </div>
                \`;
            }
        }

        async function scrapeBatch() {
            const urlsText = document.getElementById('batchUrls').value.trim();
            const batchSize = parseInt(document.getElementById('batchSize').value);
            const batchDelay = parseInt(document.getElementById('batchDelay').value);

            if (!urlsText) {
                alert('Please enter URLs');
                return;
            }

            const urls = urlsText.split('\\n').filter(url => url.trim());
            
            const progressDiv = document.getElementById('batchProgress');
            const resultsDiv = document.getElementById('batchResults');
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');

            progressDiv.style.display = 'block';
            resultsDiv.style.display = 'none';

            try {
                const response = await fetch('/api/scrape-batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        urls: urls,
                        options: {
                            batchSize: batchSize,
                            batchDelay: batchDelay
                        }
                    })
                });

                const data = await response.json();
                
                progressFill.style.width = '100%';
                progressText.textContent = 'Completed!';
                
                setTimeout(() => {
                    progressDiv.style.display = 'none';
                    resultsDiv.style.display = 'block';
                    displayBatchResults(data, resultsDiv);
                }, 1000);

            } catch (error) {
                progressDiv.style.display = 'none';
                resultsDiv.style.display = 'block';
                resultsDiv.innerHTML = \`<p class="error">Error: \${error.message}</p>\`;
            }
        }

        function displayBatchResults(data, container) {
            container.innerHTML = \`
                <h4>Batch Scraping Results</h4>
                <p><strong>Total URLs:</strong> \${data.summary.total}</p>
                <p><strong>Successful:</strong> <span class="success">\${data.summary.successful}</span></p>
                <p><strong>Failed:</strong> <span class="error">\${data.summary.failed}</span></p>
                <details style="margin-top: 15px;">
                    <summary>Detailed Results</summary>
                    <div style="max-height: 300px; overflow-y: auto; margin-top: 10px;">
                        \${data.results.map((result, index) => \`
                            <div style="margin-bottom: 10px; padding: 10px; background: \${result.value?.success ? '#d1fae5' : '#fee2e2'}; border-radius: 4px;">
                                <strong>URL \${index + 1}:</strong> \${result.value?.success ? '✅' : '❌'}<br>
                                \${result.value?.method ? \`<small>Method: \${result.value.method}</small>\` : ''}
                                \${result.reason ? \`<br><small>Error: \${result.reason}</small>\` : ''}
                            </div>
                        \`).join('')}
                    </div>
                </details>
            \`;
        }

        async function detectPagination() {
            const url = document.getElementById('paginationUrl').value.trim();

            if (!url) {
                alert('Please enter a URL');
                return;
            }

            const resultsDiv = document.getElementById('paginationResults');
            resultsDiv.style.display = 'block';
            resultsDiv.innerHTML = '<p>Detecting pagination...</p>';

            try {
                const response = await fetch('/api/detect-pagination', {
                    method: '
-- =============================================================================
-- ENHANCED KOKORO TTS DATABASE SCHEMA FOR CLOUDFLARE D1
-- Supports batch processing, queue management, and file storage
-- =============================================================================

-- TTS Processing Queue Table
CREATE TABLE IF NOT EXISTS tts_queue (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    content TEXT NOT NULL,
    voice TEXT DEFAULT 'af_sky',
    speed REAL DEFAULT 1.0,
    language TEXT DEFAULT 'en',
    status TEXT DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'error'
    uploaded_at TEXT DEFAULT (datetime('now')),
    processed_at TEXT,
    audio_data TEXT, -- Base64 encoded MP3 data
    file_size INTEGER,
    error_message TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

-- TTS Processing Statistics Table  
CREATE TABLE IF NOT EXISTS tts_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    process_date TEXT DEFAULT (datetime('now')),
    items_processed INTEGER DEFAULT 0,
    items_failed INTEGER DEFAULT 0,
    total_characters INTEGER DEFAULT 0,
    total_audio_size INTEGER DEFAULT 0,
    avg_processing_time_ms INTEGER DEFAULT 0
);

-- User Sessions Table (optional for tracking)
CREATE TABLE IF NOT EXISTS tts_sessions (
    id TEXT PRIMARY KEY,
    user_identifier TEXT,
    session_start TEXT DEFAULT (datetime('now')),
    session_end TEXT,
    items_generated INTEGER DEFAULT 0,
    total_characters INTEGER DEFAULT 0
);

-- TTS Settings/Presets Table
CREATE TABLE IF NOT EXISTS tts_presets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    voice TEXT NOT NULL,
    speed REAL NOT NULL,
    language TEXT NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_tts_queue_status ON tts_queue(status);
CREATE INDEX IF NOT EXISTS idx_tts_queue_uploaded_at ON tts_queue(uploaded_at DESC);
CREATE INDEX IF NOT EXISTS idx_tts_queue_status_uploaded ON tts_queue(status, uploaded_at);
CREATE INDEX IF NOT EXISTS idx_tts_stats_date ON tts_stats(process_date DESC);

-- Insert default presets
INSERT OR IGNORE INTO tts_presets (name, voice, speed, language, description, is_default) VALUES 
    ('Default Female', 'af_sky', 1.0, 'en', 'Standard female voice at normal speed', 1),
    ('Default Male', 'am_adam', 1.0, 'en', 'Standard male voice at normal speed', 0),
    ('Fast Reading', 'af_sky', 1.3, 'en', 'Female voice for fast content consumption', 0),
    ('Slow Learning', 'am_michael', 0.8, 'en', 'Male voice for educational content', 0),
    ('Dramatic Reading', 'af_bella', 0.9, 'en', 'Expressive female voice for storytelling', 0);
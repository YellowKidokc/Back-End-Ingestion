// =============================================================================
// ENHANCED KOKORO TTS - BATCH PROCESSING SYSTEM
// Features: File Upload, Batch Processing, Auto-Download, Queue Management
// =============================================================================

export default {
    async fetch(request, env, ctx) {
        return await handleRequest(request, env, ctx);
    }
};

async function handleRequest(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // CORS headers
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };

    if (method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    try {
        // API Routes
        if (path.startsWith('/api/')) {
            return await handleAPIRequest(request, env, corsHeaders);
        }

        // Main Dashboard
        return new Response(generateEnhancedTTSHTML(), {
            headers: { 
                'Content-Type': 'text/html',
                ...corsHeaders 
            }
        });

    } catch (error) {
        console.error('Error handling request:', error);
        return new Response(JSON.stringify({ 
            error: 'Internal server error',
            details: error.message 
        }), {
            status: 500,
            headers: { 
                'Content-Type': 'application/json',
                ...corsHeaders 
            }
        });
    }
}

async function handleAPIRequest(request, env, corsHeaders) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // Upload files for batch processing
    if (path === '/api/upload' && method === 'POST') {
        try {
            const formData = await request.formData();
            const files = [];
            
            for (const [key, value] of formData.entries()) {
                if (key.startsWith('file')) {
                    const file = value;
                    const content = await file.text();
                    
                    files.push({
                        id: crypto.randomUUID(),
                        name: file.name,
                        content: content,
                        size: content.length,
                        uploaded_at: new Date().toISOString(),
                        status: 'pending',
                        voice: formData.get('voice') || 'af_sky',
                        speed: parseFloat(formData.get('speed')) || 1.0,
                        language: formData.get('language') || 'en'
                    });
                }
            }

            // Store files in D1 database
            for (const file of files) {
                await env.TTS_DB.prepare(`
                    INSERT INTO tts_queue 
                    (id, name, content, voice, speed, language, status, uploaded_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                `).bind(
                    file.id,
                    file.name,
                    file.content,
                    file.voice,
                    file.speed,
                    file.language,
                    file.status,
                    file.uploaded_at
                ).run();
            }

            return new Response(JSON.stringify({
                success: true,
                uploaded: files.length,
                files: files.map(f => ({ id: f.id, name: f.name, size: f.size }))
            }), {
                headers: { 'Content-Type': 'application/json', ...corsHeaders }
            });

        } catch (error) {
            return new Response(JSON.stringify({
                error: 'Upload failed',
                details: error.message
            }), {
                status: 400,
                headers: { 'Content-Type': 'application/json', ...corsHeaders }
            });
        }
    }

    // Get queue status
    if (path === '/api/queue' && method === 'GET') {
        const queue = await env.TTS_DB.prepare(`
            SELECT id, name, status, voice, speed, language, uploaded_at, processed_at, error_message
            FROM tts_queue 
            ORDER BY uploaded_at DESC 
            LIMIT 50
        `).all();

        const stats = await env.TTS_DB.prepare(`
            SELECT 
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
                COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                COUNT(CASE WHEN status = 'error' THEN 1 END) as errors
            FROM tts_queue
        `).first();

        return new Response(JSON.stringify({
            success: true,
            queue: queue.results,
            stats: stats
        }), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }

    // Process next item in queue
    if (path === '/api/process' && method === 'POST') {
        return await processNextInQueue(env, corsHeaders);
    }

    // Process all items in queue
    if (path === '/api/process-all' && method === 'POST') {
        return await processAllInQueue(env, corsHeaders);
    }

    // Download processed MP3
    if (path.startsWith('/api/download/') && method === 'GET') {
        const fileId = path.split('/')[3];
        return await downloadMP3(env, fileId, corsHeaders);
    }

    // Single TTS generation (original functionality)
    if (path === '/api/generate' && method === 'POST') {
        const data = await request.json();
        return await generateSingleTTS(data, corsHeaders);
    }

    // Clear completed items
    if (path === '/api/clear-completed' && method === 'POST') {
        await env.TTS_DB.prepare(`
            DELETE FROM tts_queue 
            WHERE status IN ('completed', 'error')
        `).run();

        return new Response(JSON.stringify({ success: true }), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }

    return new Response('Not Found', { 
        status: 404,
        headers: corsHeaders 
    });
}

async function processNextInQueue(env, corsHeaders) {
    try {
        // Get next pending item
        const nextItem = await env.TTS_DB.prepare(`
            SELECT * FROM tts_queue 
            WHERE status = 'pending' 
            ORDER BY uploaded_at ASC 
            LIMIT 1
        `).first();

        if (!nextItem) {
            return new Response(JSON.stringify({
                success: false,
                message: 'No pending items in queue'
            }), {
                headers: { 'Content-Type': 'application/json', ...corsHeaders }
            });
        }

        return await processTTSItem(env, nextItem, corsHeaders);

    } catch (error) {
        return new Response(JSON.stringify({
            error: 'Processing failed',
            details: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }
}

async function processAllInQueue(env, corsHeaders) {
    try {
        const pendingItems = await env.TTS_DB.prepare(`
            SELECT * FROM tts_queue 
            WHERE status = 'pending' 
            ORDER BY uploaded_at ASC
        `).all();

        if (pendingItems.results.length === 0) {
            return new Response(JSON.stringify({
                success: false,
                message: 'No pending items in queue'
            }), {
                headers: { 'Content-Type': 'application/json', ...corsHeaders }
            });
        }

        let processed = 0;
        let errors = 0;

        // Process each item sequentially
        for (const item of pendingItems.results) {
            try {
                await processTTSItem(env, item, corsHeaders);
                processed++;
                
                // Small delay between items to prevent overwhelming the TTS service
                await new Promise(resolve => setTimeout(resolve, 1000));
                
            } catch (error) {
                console.error(`Error processing item ${item.id}:`, error);
                errors++;
                
                // Mark as error
                await env.TTS_DB.prepare(`
                    UPDATE tts_queue 
                    SET status = 'error', error_message = ?, processed_at = ?
                    WHERE id = ?
                `).bind(error.message, new Date().toISOString(), item.id).run();
            }
        }

        return new Response(JSON.stringify({
            success: true,
            processed: processed,
            errors: errors,
            total: pendingItems.results.length
        }), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });

    } catch (error) {
        return new Response(JSON.stringify({
            error: 'Batch processing failed',
            details: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }
}

async function processTTSItem(env, item, corsHeaders) {
    // Mark as processing
    await env.TTS_DB.prepare(`
        UPDATE tts_queue 
        SET status = 'processing' 
        WHERE id = ?
    `).bind(item.id).run();

    try {
        // Call Kokoro TTS API (adjust URL to your Synology NAS)
        const kokoroUrl = 'http://192.168.1.177:8343/api/tts'; // Update with your NAS IP
        
        const ttsResponse = await fetch(kokoroUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: item.content,
                voice: item.voice,
                speed: item.speed,
                language: item.language
            })
        });

        if (!ttsResponse.ok) {
            throw new Error(`TTS API returned ${ttsResponse.status}: ${ttsResponse.statusText}`);
        }

        // Get the audio data
        const audioBuffer = await ttsResponse.arrayBuffer();
        
        // Store MP3 in Cloudflare R2 or as base64 in D1 (for demo, using base64)
        const base64Audio = btoa(String.fromCharCode(...new Uint8Array(audioBuffer)));

        // Update database with completed status
        await env.TTS_DB.prepare(`
            UPDATE tts_queue 
            SET status = 'completed', audio_data = ?, processed_at = ?
            WHERE id = ?
        `).bind(base64Audio, new Date().toISOString(), item.id).run();

        return {
            success: true,
            item_id: item.id,
            audio_size: audioBuffer.byteLength
        };

    } catch (error) {
        // Mark as error
        await env.TTS_DB.prepare(`
            UPDATE tts_queue 
            SET status = 'error', error_message = ?, processed_at = ?
            WHERE id = ?
        `).bind(error.message, new Date().toISOString(), item.id).run();

        throw error;
    }
}

async function downloadMP3(env, fileId, corsHeaders) {
    try {
        const item = await env.TTS_DB.prepare(`
            SELECT * FROM tts_queue 
            WHERE id = ? AND status = 'completed'
        `).bind(fileId).first();

        if (!item || !item.audio_data) {
            return new Response('File not found or not processed', { 
                status: 404,
                headers: corsHeaders 
            });
        }

        // Convert base64 back to binary
        const audioBuffer = Uint8Array.from(atob(item.audio_data), c => c.charCodeAt(0));

        return new Response(audioBuffer, {
            headers: {
                'Content-Type': 'audio/mpeg',
                'Content-Disposition': `attachment; filename="${item.name.replace(/\.[^/.]+$/, '')}.mp3"`,
                'Content-Length': audioBuffer.length.toString(),
                ...corsHeaders
            }
        });

    } catch (error) {
        return new Response(JSON.stringify({
            error: 'Download failed',
            details: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }
}

async function generateSingleTTS(data, corsHeaders) {
    try {
        // Call Kokoro TTS API
        const kokoroUrl = 'http://192.168.1.177:8343/api/tts'; // Update with your NAS IP
        
        const ttsResponse = await fetch(kokoroUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: data.text,
                voice: data.voice || 'af_sky',
                speed: data.speed || 1.0,
                language: data.language || 'en'
            })
        });

        if (!ttsResponse.ok) {
            throw new Error(`TTS API returned ${ttsResponse.status}`);
        }

        const audioBuffer = await ttsResponse.arrayBuffer();
        const base64Audio = btoa(String.fromCharCode(...new Uint8Array(audioBuffer)));

        return new Response(JSON.stringify({
            success: true,
            audio_data: base64Audio,
            size: audioBuffer.byteLength
        }), {
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });

    } catch (error) {
        return new Response(JSON.stringify({
            error: 'TTS generation failed',
            details: error.message
        }), {
            status: 500,
            headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
    }
}

function generateEnhancedTTSHTML() {
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhanced Kokoro TTS - Batch Processing</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .tabs { display: flex; background: white; border-radius: 8px; margin-bottom: 20px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .tab { flex: 1; padding: 15px; text-align: center; cursor: pointer; border: none; background: none; font-size: 16px; }
        .tab.active { background: #2563eb; color: white; }
        .tab:hover:not(.active) { background: #f3f4f6; }
        .tab-content { display: none; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .tab-content.active { display: block; }
        .upload-area { border: 2px dashed #d1d5db; border-radius: 8px; padding: 40px; text-align: center; margin-bottom: 20px; }
        .upload-area.dragover { border-color: #2563eb; background: #eff6ff; }
        .file-input { display: none; }
        .btn { padding: 10px 20px; background: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }
        .btn:hover { background: #1d4ed8; }
        .btn-danger { background: #dc2626; }
        .btn-danger:hover { background: #b91c1c; }
        .btn-success { background: #059669; }
        .btn-success:hover { background: #047857; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-card { background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stat-number { font-size: 1.5em; font-weight: bold; color: #2563eb; }
        .stat-label { color: #6b7280; font-size: 0.9em; }
        .queue-item { background: #f9fafb; padding: 15px; border-radius: 8px; margin-bottom: 10px; display: flex; justify-content: between; align-items: center; }
        .queue-item.processing { background: #fef3c7; }
        .queue-item.completed { background: #d1fae5; }
        .queue-item.error { background: #fee2e2; }
        .queue-info { flex: 1; }
        .queue-actions { display: flex; gap: 10px; }
        .status-badge { padding: 4px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; }
        .status-pending { background: #fbbf24; color: #92400e; }
        .status-processing { background: #3b82f6; color: white; }
        .status-completed { background: #10b981; color: white; }
        .status-error { background: #ef4444; color: white; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 4px; }
        .textarea-large { min-height: 100px; resize: vertical; }
        .loading { opacity: 0.6; pointer-events: none; }
        .success { color: #059669; font-weight: 500; }
        .error { color: #dc2626; font-weight: 500; }
        .progress-bar { width: 100%; height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; margin: 10px 0; }
        .progress-fill { height: 100%; background: #2563eb; transition: width 0.3s ease; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Enhanced Kokoro TTS System</h1>
            <p>Text-to-Speech with Batch Processing, File Upload & Auto-Download</p>
        </div>

        <div class="tabs">
            <button class="tab active" onclick="switchTab('single')">Single TTS</button>
            <button class="tab" onclick="switchTab('batch')">Batch Upload</button>
            <button class="tab" onclick="switchTab('queue')">Processing Queue</button>
        </div>

        <!-- Single TTS Tab -->
        <div class="tab-content active" id="single-tab">
            <h3>Single Text-to-Speech Generation</h3>
            <div class="form-group">
                <label for="singleText">Text to Convert:</label>
                <textarea id="singleText" class="textarea-large" placeholder="Enter your text here..."></textarea>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
                <div class="form-group">
                    <label for="singleVoice">Voice:</label>
                    <select id="singleVoice">
                        <option value="af_sky">Sky (Female)</option>
                        <option value="af_bella">Bella (Female)</option>
                        <option value="am_adam">Adam (Male)</option>
                        <option value="am_michael">Michael (Male)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="singleSpeed">Speed:</label>
                    <select id="singleSpeed">
                        <option value="0.8">Slow (0.8x)</option>
                        <option value="1.0" selected>Normal (1.0x)</option>
                        <option value="1.2">Fast (1.2x)</option>
                        <option value="1.5">Very Fast (1.5x)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="singleLanguage">Language:</label>
                    <select id="singleLanguage">
                        <option value="en" selected>English</option>
                        <option value="es">Spanish</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                    </select>
                </div>
            </div>
            <button class="btn" onclick="generateSingle()">Generate Speech</button>
            <div id="singleResult" style="margin-top: 20px;"></div>
        </div>

        <!-- Batch Upload Tab -->
        <div class="tab-content" id="batch-tab">
            <h3>Batch File Upload</h3>
            <div class="upload-area" id="uploadArea">
                <p style="font-size: 1.2em; margin-bottom: 10px;">📁 Drop files here or click to upload</p>
                <p style="color: #6b7280;">Supports: .txt, .md, .docx files</p>
                <input type="file" id="fileInput" class="file-input" multiple accept=".txt,.md,.docx">
                <button class="btn" onclick="document.getElementById('fileInput').click()">Choose Files</button>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div class="form-group">
                    <label for="batchVoice">Default Voice:</label>
                    <select id="batchVoice">
                        <option value="af_sky">Sky (Female)</option>
                        <option value="af_bella">Bella (Female)</option>
                        <option value="am_adam">Adam (Male)</option>
                        <option value="am_michael">Michael (Male)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="batchSpeed">Default Speed:</label>
                    <select id="batchSpeed">
                        <option value="0.8">Slow (0.8x)</option>
                        <option value="1.0" selected>Normal (1.0x)</option>
                        <option value="1.2">Fast (1.2x)</option>
                        <option value="1.5">Very Fast (1.5x)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="batchLanguage">Default Language:</label>
                    <select id="batchLanguage">
                        <option value="en" selected>English</option>
                        <option value="es">Spanish</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                    </select>
                </div>
            </div>

            <div id="selectedFiles" style="margin-bottom: 20px;"></div>
            <button class="btn" id="uploadBtn" onclick="uploadFiles()" disabled>Upload Files to Queue</button>
        </div>

        <!-- Queue Tab -->
        <div class="tab-content" id="queue-tab">
            <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 20px;">
                <h3>Processing Queue</h3>
                <div>
                    <button class="btn" onclick="loadQueue()">Refresh</button>
                    <button class="btn btn-success" onclick="processNext()">Process Next</button>
                    <button class="btn btn-success" onclick="processAll()">Process All</button>
                    <button class="btn btn-danger" onclick="clearCompleted()">Clear Completed</button>
                </div>
            </div>

            <div class="stats" id="queueStats">
                <div class="stat-card">
                    <div class="stat-number" id="totalItems">-</div>
                    <div class="stat-label">Total Items</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="pendingItems">-</div>
                    <div class="stat-label">Pending</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="processingItems">-</div>
                    <div class="stat-label">Processing</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="completedItems">-</div>
                    <div class="stat-label">Completed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number" id="errorItems">-</div>
                    <div class="stat-label">Errors</div>
                </div>
            </div>

            <div id="processingProgress" style="display: none;">
                <h4>Processing Progress</h4>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: 0%;"></div>
                </div>
                <p id="progressText">Processing item 0 of 0...</p>
            </div>

            <div id="queueList">
                <p>Loading queue...</p>
            </div>
        </div>
    </div>

    <script>
        let selectedFiles = [];

        // Tab switching
        function switchTab(tabName) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });

            // Show selected tab
            document.getElementById(tabName + '-tab').classList.add('active');
            event.target.classList.add('active');

            // Load queue when switching to queue tab
            if (tabName === 'queue') {
                loadQueue();
            }
        }

        // File upload handling
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('fileInput');

        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            handleFiles(e.dataTransfer.files);
        });

        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });

        fileInput.addEventListener('change', (e) => {
            handleFiles(e.target.files);
        });

        function handleFiles(files) {
            selectedFiles = Array.from(files);
            updateFileList();
            document.getElementById('uploadBtn').disabled = selectedFiles.length === 0;
        }

        function updateFileList() {
            const container = document.getElementById('selectedFiles');
            if (selectedFiles.length === 0) {
                container.innerHTML = '';
                return;
            }

            container.innerHTML = \`
                <h4>Selected Files (\${selectedFiles.length}):</h4>
                \${selectedFiles.map((file, index) => \`
                    <div class="queue-item">
                        <div class="queue-info">
                            <strong>\${file.name}</strong><br>
                            <small>\${(file.size / 1024).toFixed(1)} KB</small>
                        </div>
                        <button class="btn btn-danger" onclick="removeFile(\${index})">Remove</button>
                    </div>
                \`).join('')}
            \`;
        }

        function removeFile(index) {
            selectedFiles.splice(index, 1);
            updateFileList();
            document.getElementById('uploadBtn').disabled = selectedFiles.length === 0;
        }

        // Single TTS generation
        async function generateSingle() {
            const text = document.getElementById('singleText').value.trim();
            if (!text) {
                alert('Please enter some text');
                return;
            }

            const resultDiv = document.getElementById('singleResult');
            resultDiv.innerHTML = '<p>Generating speech...</p>';

            try {
                const response = await fetch('/api/generate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        text: text,
                        voice: document.getElementById('singleVoice').value,
                        speed: parseFloat(document.getElementById('singleSpeed').value),
                        language: document.getElementById('singleLanguage').value
                    })
                });

                const data = await response.json();

                if (data.success) {
                    // Create audio player and download link
                    const audioBlob = new Blob([Uint8Array.from(atob(data.audio_data), c => c.charCodeAt(0))], { type: 'audio/mpeg' });
                    const audioUrl = URL.createObjectURL(audioBlob);

                    resultDiv.innerHTML = \`
                        <div class="success">✅ Speech generated successfully!</div>
                        <audio controls style="width: 100%; margin: 10px 0;">
                            <source src="\${audioUrl}" type="audio/mpeg">
                        </audio>
                        <a href="\${audioUrl}" download="tts-single.mp3" class="btn">📥 Download MP3</a>
                        <p><small>Size: \${(data.size / 1024).toFixed(1)} KB</small></p>
                    \`;
                } else {
                    resultDiv.innerHTML = \`<div class="error">❌ Error: \${data.error}</div>\`;
                }

            } catch (error) {
                resultDiv.innerHTML = \`<div class="error">❌ Error: \${error.message}</div>\`;
            }
        }

        // Upload files to queue
        async function uploadFiles() {
            if (selectedFiles.length === 0) return;

            const formData = new FormData();
            selectedFiles.forEach((file, index) => {
                formData.append(\`file\${index}\`, file);
            });
            
            formData.append('voice', document.getElementById('batchVoice').value);
            formData.append('speed', document.getElementById('batchSpeed').value);
            formData.append('language', document.getElementById('batchLanguage').value);

            document.getElementById('uploadBtn').textContent = 'Uploading...';
            document.getElementById('uploadBtn').disabled = true;

            try {
                const response = await fetch('/api/upload', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    alert(\`Successfully uploaded \${data.uploaded} files to queue!\`);
                    selectedFiles = [];
                    updateFileList();
                    switchTab('queue'); // Switch to queue tab
                } else {
                    alert(\`Upload failed: \${data.error}\`);
                }

            } catch (error) {
                alert(\`Upload error: \${error.message}\`);
            } finally {
                document.getElementById('uploadBtn').textContent = 'Upload Files to Queue';
                document.getElementById('uploadBtn').disabled = selectedFiles.length === 0;
            }
        }

        // Queue management functions
        async function loadQueue() {
            try {
                const response = await fetch('/api/queue');
                const data = await response.json();

                if (data.success) {
                    updateQueueStats(data.stats);
                    updateQueueList(data.queue);
                }
            } catch (error) {
                console.error('Failed to load queue:', error);
            }
        }

        function updateQueueStats(stats) {
            document.getElementById('totalItems').textContent = stats.total || 0;
            document.getElementById('pendingItems').textContent = stats.pending || 0;
            document.getElementById('processingItems').textContent = stats.processing || 0;
            document.getElementById('completedItems').textContent = stats.completed || 0;
            document.getElementById('errorItems').textContent = stats.errors || 0;
        }

        function updateQueueList(queue) {
            const container = document.getElementById('queueList');
            
            if (queue.length === 0) {
                container.innerHTML = '<p>No items in queue. Upload some files to get started!</p>';
                return;
            }

            container.innerHTML = queue.map(item => \`
                <div class="queue-item \${item.status}">
                    <div class="queue-info">
                        <strong>\${item.name}</strong>
                        <span class="status-badge status-\${item.status}">\${item.status.toUpperCase()}</span><br>
                        <small>Voice: \${item.voice} | Speed: \${item.speed}x | Language: \${item.language}</small><br>
                        <small>Uploaded: \${new Date(item.uploaded_at).toLocaleString()}</small>
                        \${item.processed_at ? \`<br><small>Processed: \${new Date(item.processed_at).toLocaleString()}</small>\` : ''}
                        \${item.error_message ? \`<br><small class="error">Error: \${item.error_message}</small>\` : ''}
                    </div>
                    <div class="queue-actions">
                        \${item.status === 'completed' ? \`
                            <button class="btn btn-success" onclick="downloadFile('\${item.id}', '\${item.name}')">📥 Download</button>
                        \` : ''}
                    </div>
                </div>
            \`).join('');
        }

        async function processNext() {
            try {
                const response = await fetch('/api/process', { method: 'POST' });
                const data = await response.json();

                if (data.success) {
                    alert('Item processed successfully!');
                    loadQueue();
                } else {
                    alert(\`Processing failed: \${data.message || 'Unknown error'}\`);
                }
            } catch (error) {
                alert(\`Processing error: \${error.message}\`);
            }
        }

        async function processAll() {
            const progressDiv = document.getElementById('processingProgress');
            const progressFill = document.getElementById('progressFill');
            const progressText = document.getElementById('progressText');

            progressDiv.style.display = 'block';
            progressFill.style.width = '0%';
            progressText.textContent = 'Starting batch processing...';

            try {
                const response = await fetch('/api/process-all', { method: 'POST' });
                const data = await response.json();

                if (data.success) {
                    progressFill.style.width = '100%';
                    progressText.textContent = \`Completed! Processed: \${data.processed}, Errors: \${data.errors}\`;
                    
                    setTimeout(() => {
                        progressDiv.style.display = 'none';
                        loadQueue();
                    }, 2000);
                } else {
                    alert(\`Batch processing failed: \${data.message || 'Unknown error'}\`);
                    progressDiv.style.display = 'none';
                }
            } catch (error) {
                alert(\`Batch processing error: \${error.message}\`);
                progressDiv.style.display = 'none';
            }
        }

        async function clearCompleted() {
            if (!confirm('Are you sure you want to clear all completed and error items?')) {
                return;
            }

            try {
                const response = await fetch('/api/clear-completed', { method: 'POST' });
                const data = await response.json();

                if (data.success) {
                    alert('Completed items cleared!');
                    loadQueue();
                }
            } catch (error) {
                alert(\`Clear failed: \${error.message}\`);
            }
        }

        async function downloadFile(fileId, fileName) {
            try {
                const response = await fetch(\`/api/download/\${fileId}\`);
                
                if (response.ok) {
                    const blob = await response.blob();
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = fileName.replace(/\.[^/.]+$/, '') + '.mp3';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                } else {
                    alert('Download failed');
                }
            } catch (error) {
                alert(\`Download error: \${error.message}\`);
            }
        }

        // Auto-refresh queue every 30 seconds when on queue tab
        setInterval(() => {
            if (document.getElementById('queue-tab').classList.contains('active')) {
                loadQueue();
            }
        }, 30000);

        // Load queue on page load
        loadQueue();
    </script>
</body>
</html>`;
}
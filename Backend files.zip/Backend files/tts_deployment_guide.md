# 🎵 Enhanced Kokoro TTS Deployment Guide

## **🎯 What This Adds to Your Kokoro Setup:**

✅ **Batch File Upload** - Upload multiple .txt, .md files at once  
✅ **Auto-Download** - Automatically download MP3s when processing completes  
✅ **Queue Management** - Process files one by one or all at once  
✅ **Progress Tracking** - Real-time status of all TTS jobs  
✅ **File Management** - Upload → Process → Download workflow  

## **🚀 Step-by-Step Deployment**

### **Step 1: Keep Your Existing Kokoro**
Your current Kokoro setup on Synology NAS stays exactly the same! This enhancement works alongside it.

```bash
# Your existing Kokoro is running at:
# http://192.168.1.177:8343/web/
# ✅ Keep this running - don't change anything!
```

### **Step 2: Create Enhanced TTS Cloudflare Worker**

**2a. Create new project folder:**
```bash
mkdir enhanced-kokoro-tts
cd enhanced-kokoro-tts
```

**2b. Create `wrangler.toml`:**
```toml
name = "enhanced-kokoro-tts"
main = "enhanced-tts.js"
compatibility_date = "2024-07-07"

# Create new D1 database for TTS queue
[[d1_databases]]
binding = "TTS_DB"
database_name = "kokoro-tts-queue"
database_id = "YOUR_TTS_DATABASE_ID"  # Update after creating database
```

**2c. Create the D1 database:**
```bash
npx wrangler d1 create kokoro-tts-queue

# Output will give you database ID - update wrangler.toml
# Example: database_id = "12345678-1234-1234-1234-123456789abc"
```

**2d. Apply the database schema:**
```bash
# Save the TTS schema (from artifact above) as tts-schema.sql
npx wrangler d1 execute kokoro-tts-queue --file=tts-schema.sql
```

### **Step 3: Update the Worker Code**

**3a. Create `enhanced-tts.js`:**
Copy the Enhanced Kokoro TTS code from the artifact above.

**3b. Update your Synology NAS IP:**
```javascript
// In the processTTSItem function, update this line:
const kokoroUrl = 'http://192.168.1.177:8343/api/tts'; // Your actual NAS IP
```

**3c. Deploy to Cloudflare:**
```bash
npx wrangler deploy

# You'll get a URL like:
# https://enhanced-kokoro-tts.your-subdomain.workers.dev
```

### **Step 4: Test the Enhanced System**

**4a. Access the new interface:**
Visit your new Cloudflare Worker URL in browser

**4b. Test single TTS:**
- Go to "Single TTS" tab
- Enter some text
- Click "Generate Speech"
- Should work exactly like before + auto-download

**4c. Test batch upload:**
- Go to "Batch Upload" tab  
- Drop some .txt or .md files
- Set voice/speed preferences
- Click "Upload Files to Queue"

**4d. Test batch processing:**
- Go to "Processing Queue" tab
- Click "Process All" to convert all files
- Watch progress and download completed MP3s

## **📁 Project Structure**

```
/your-kokoro-project/
├── /synology-kokoro/          ← Your existing Kokoro (unchanged)
│   └── docker-compose.yml     ← Running on port 8343
```
/your-kokoro-project/
├── /synology-kokoro/          ← Your existing Kokoro (unchanged)
│   └── docker-compose.yml     ← Running on port 8343
├── /enhanced-kokoro-tts/      ← New Cloudflare enhancement
│   ├── enhanced-tts.js        ← Worker code
│   ├── wrangler.toml          ← Cloudflare config
│   └── tts-schema.sql         ← Database schema
└── README.md
```

## **🔗 How It All Works Together**

### **Architecture Flow:**
```
1. User uploads files → Cloudflare Worker (Queue)
2. Worker calls → Your Synology Kokoro API
3. Kokoro generates → MP3 audio
4. Worker stores → MP3 in database
5. User downloads → Completed MP3s
```

### **Two Ways to Use:**
- **Original**: http://192.168.1.177:8343/web/ (your existing interface)
- **Enhanced**: https://enhanced-kokoro-tts.your-subdomain.workers.dev (new batch interface)

## **🎯 New Features Explained**

### **1. Batch File Upload**
```
✅ Drag & drop multiple files
✅ Supports .txt, .md, .docx files  
✅ Set voice/speed/language for all files
✅ Queue management system
```

### **2. Auto-Download System**
```
✅ Automatic MP3 generation
✅ One-click download when ready
✅ Proper filename handling
✅ Progress tracking
```

### **3. Three-Step Workflow You Requested**
```
Step 1: Upload markdown/text files ✅
Step 2: Auto-process → Generate MP3s ✅  
Step 3: Auto-download completed MP3s ✅
```

## **⚙️ Configuration Options**

### **Voice Options:**
- `af_sky` - Sky (Female)
- `af_bella` - Bella (Female) 
- `am_adam` - Adam (Male)
- `am_michael` - Michael (Male)

### **Speed Options:**
- `0.8` - Slow (0.8x)
- `1.0` - Normal (1.0x)
- `1.2` - Fast (1.2x)
- `1.5` - Very Fast (1.5x)

### **Language Options:**
- `en` - English
- `es` - Spanish
- `fr` - French  
- `de` - German

## **🔧 Troubleshooting**

### **Common Issues:**

**1. "TTS API connection failed"**
```bash
# Check your Synology NAS IP in the code:
const kokoroUrl = 'http://192.168.1.177:8343/api/tts';

# Make sure Kokoro is running:
curl http://192.168.1.177:8343/web/
```

**2. "Database not found"**
```bash
# Apply the schema:
npx wrangler d1 execute kokoro-tts-queue --file=tts-schema.sql

# Check database exists:
npx wrangler d1 list
```

**3. "Files not uploading"**
- Check file format (only .txt, .md, .docx supported)
- Check file size (keep under 1MB per file)
- Check browser console for errors

**4. "Processing stuck"**
- Check if Kokoro Docker container is running
- Verify network connectivity to NAS
- Check Worker logs: `npx wrangler tail`

### **Testing Commands:**

```bash
# Test Kokoro API directly
curl -X POST http://192.168.1.177:8343/api/tts \
  -H "Content-Type: application/json" \
  -d '{"text":"Hello world","voice":"af_sky","speed":1.0}'

# Test Cloudflare Worker
curl https://enhanced-kokoro-tts.your-subdomain.workers.dev/api/queue

# Check D1 database
npx wrangler d1 execute kokoro-tts-queue --command="SELECT COUNT(*) FROM tts_queue"
```

## **🎉 Success Indicators**

✅ **Enhanced interface loads** - Visit worker URL, see 3 tabs  
✅ **File upload works** - Drop files, see them in queue  
✅ **Single TTS works** - Enter text, get MP3 download  
✅ **Batch processing works** - Process all files, download MP3s  
✅ **Queue management works** - See status, clear completed items  

## **🚀 Advanced Features**

### **API Endpoints:**
- `POST /api/upload` - Upload files to queue
- `GET /api/queue` - Get queue status  
- `POST /api/process` - Process next item
- `POST /api/process-all` - Process all pending
- `GET /api/download/{id}` - Download MP3
- `POST /api/clear-completed` - Clear finished items

### **Database Tables:**
- `tts_queue` - Main processing queue
- `tts_stats` - Processing statistics
- `tts_presets` - Voice/speed presets
- `tts_sessions` - User session tracking

### **Batch Processing Logic:**
```
1. Upload files → Store in tts_queue (status: pending)
2. Process → Call Kokoro API (status: processing)  
3. Complete → Store MP3 data (status: completed)
4. Download → Serve MP3 file
5. Cleanup → Remove old completed items
```

## **💡 Tips for Best Results**

### **File Preparation:**
- Keep text files under 5000 characters for best results
- Use clear, well-formatted text (avoid special characters)
- Separate different sections into different files
- Use descriptive filenames

### **Voice Selection:**
- **af_sky**: Best for general content, clear pronunciation
- **af_bella**: Good for storytelling, expressive reading
- **am_adam**: Professional male voice, good for business content
- **am_michael**: Deeper male voice, good for dramatic content

### **Processing Tips:**
- Process files during off-peak hours to avoid overwhelming your NAS
- Use "Process Next" for testing individual files
- Use "Process All" for large batches when you can wait
- Clear completed items regularly to keep queue manageable

## **📈 What You've Gained**

Your enhanced Kokoro TTS system now supports:

🎵 **Original functionality** - Still works exactly as before  
📁 **Batch file upload** - Drop multiple files at once  
🔄 **Queue management** - Organized processing workflow  
📥 **Auto-download** - Get MP3s automatically when ready  
📊 **Progress tracking** - See status of all jobs  
🌐 **Global access** - Use from anywhere via Cloudflare  
🔧 **No server maintenance** - Cloudflare handles scaling  

You now have a professional-grade TTS system with the exact workflow you requested! 🎉